"""
app.py — MediBot AI Health Intelligence Assistant
══════════════════════════════════════════════════
Entry point for the Streamlit application.

Mandatory Features (NeoStats brief):
  ✅  RAG Integration       — ChromaDB + sentence-transformers
  ✅  Live Web Search       — Tavily → DuckDuckGo fallback
  ✅  Response Modes        — Concise / Detailed (+ ELI5 bonus)
  ✅  Multi-LLM             — OpenAI · Groq · Gemini (streaming)
  ✅  Modular structure     — config/ models/ utils/
  ✅  No hard-coded secrets — env vars via config/config.py

Additional Features:
  ✅  ELI5 response mode
  ✅  Emergency keyword detection + Indian helpline numbers
  ✅  Session analytics dashboard (queries, RAG hits, web hits)
  ✅  Multi-format document upload (PDF, TXT, DOCX, MD)
  ✅  Knowledge-base management (index / clear)
  ✅  Chat history export (.txt download)
  ✅  Temperature slider for creativity control
  ✅  Source badges (RAG / Web) on every bot message
  ✅  Beautiful custom dark theme (Syne + DM Sans fonts)
  ✅  Streaming token responses
  ✅  Query auto-classification for analytics
"""

import os
import logging
import tempfile
from datetime import datetime

import streamlit as st

from config.config import APP_NAME, APP_TAGLINE, APP_VERSION, DEFAULT_PROVIDER
from models.llm import get_llm_response, get_available_providers
from utils.rag_utils import (
    index_document, retrieve_relevant_chunks, build_rag_context,
    get_collection_stats, clear_collection, get_or_create_collection,
)
from utils.web_search import web_search, format_search_results, should_search_web
from utils.chat_utils import (
    build_messages, format_chat_for_export,
    classify_query, detect_emergency, EMERGENCY_BANNER,
)
from utils.analytics import init_analytics, record_query, get_summary

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ══════════════════════════════════════════════════════════════════════════════
# PAGE CONFIG
# ══════════════════════════════════════════════════════════════════════════════
st.set_page_config(
    page_title="MediBot — AI Health Assistant",
    page_icon="🩺",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ══════════════════════════════════════════════════════════════════════════════
# GLOBAL CSS
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&display=swap');

:root {
  --bg:        #080d18;
  --card:      #0f1623;
  --border:    rgba(0,212,170,.14);
  --accent:    #00d4aa;
  --acsoft:    rgba(0,212,170,.10);
  --acglow:    rgba(0,212,170,.25);
  --blue:      #7eb8f7;
  --blsoft:    rgba(126,184,247,.10);
  --text:      #edf2f7;
  --muted:     #7a8fa6;
  --danger:    #ff6b6b;
  --warn:      #ffd166;
  --hdisplay:  'Syne', sans-serif;
  --hbody:     'DM Sans', sans-serif;
}

html, body, [class*="css"] { font-family: var(--hbody) !important; background: var(--bg) !important; color: var(--text) !important; }
#MainMenu, footer, header { visibility: hidden; }
.stDeployButton { display: none; }

/* ── Sidebar ── */
[data-testid="stSidebar"] {
  background: linear-gradient(180deg,#0b1120 0%,#080d18 100%) !important;
  border-right: 1px solid var(--border) !important;
}

/* ── Block container ── */
.block-container { padding: 2rem 2.5rem !important; max-width: 860px !important; margin: 0 auto !important; }

/* ── Header ── */
.mb-header { text-align:center; padding: 2rem 0 1rem; }
.mb-header h1 {
  font-family: var(--hdisplay) !important;
  font-size: 2.6rem !important; font-weight: 800 !important; margin: 0 !important;
  background: linear-gradient(135deg, #00d4aa 0%, #7eb8f7 60%, #a78bfa 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
  letter-spacing: -.025em;
}
.mb-header p { color: var(--muted); font-size:.95rem; margin:.4rem 0 0; font-weight:300; letter-spacing:.03em; }
.mb-badge {
  display:inline-block; margin-top:.6rem;
  background:var(--acsoft); color:var(--accent); border:1px solid var(--border);
  padding:.12rem .65rem; border-radius:999px; font-size:.68rem; font-weight:700; letter-spacing:.1em;
}

/* ── Status pills ── */
.pills { display:flex; gap:.4rem; justify-content:center; flex-wrap:wrap; margin:.8rem 0; }
.pill {
  display:inline-flex; align-items:center; gap:.3rem;
  padding:.2rem .7rem; border-radius:999px; font-size:.7rem; font-weight:500; border:1px solid;
}
.pill-on  { background:rgba(0,212,170,.08); color:#00d4aa; border-color:rgba(0,212,170,.3); }
.pill-off { background:rgba(255,107,107,.08); color:#ff9999; border-color:rgba(255,107,107,.3); }
.pill-warn{ background:rgba(255,209,102,.08); color:#ffd166; border-color:rgba(255,209,102,.3); }

/* ── Chat messages ── */
.msg { display:flex; gap:.7rem; align-items:flex-start; margin-bottom:.9rem; animation:fadeUp .2s ease; }
.msg.user { flex-direction:row-reverse; }
.avatar {
  width:36px; height:36px; border-radius:50%;
  display:flex; align-items:center; justify-content:center; font-size:1rem; flex-shrink:0;
}
.avatar.bot  { background:var(--acsoft); border:1px solid var(--border); }
.avatar.user { background:var(--blsoft); border:1px solid rgba(126,184,247,.2); }
.bubble { max-width:76%; padding:.8rem 1.1rem; border-radius:1rem; font-size:.92rem; line-height:1.65; word-break:break-word; }
.bubble.bot  { background:rgba(255,255,255,.025); border:1px solid var(--border); border-top-left-radius:.15rem; }
.bubble.user { background:var(--acsoft); border:1px solid rgba(0,212,170,.2); border-top-right-radius:.15rem; }
.meta { font-size:.66rem; color:var(--muted); margin-top:.3rem; opacity:.75; }
.tag {
  display:inline-flex; align-items:center; gap:.25rem;
  font-size:.66rem; padding:.15rem .5rem; border-radius:999px; margin:.25rem .15rem 0 0; font-weight:500;
}
.tag-rag { background:var(--blsoft); color:var(--blue); border:1px solid rgba(126,184,247,.25); }
.tag-web { background:rgba(255,209,102,.1); color:#ffd166; border:1px solid rgba(255,209,102,.25); }

@keyframes fadeUp { from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:translateY(0)} }

/* ── Emergency banner ── */
.emg {
  background:rgba(255,107,107,.09); border:1px solid rgba(255,107,107,.4);
  border-left:4px solid #ff6b6b; border-radius:.75rem; padding:1rem 1.2rem;
  margin:.8rem 0; font-size:.88rem; color:#ffb3b3;
}

/* ── Sidebar section label ── */
.slabel {
  font-family:var(--hdisplay); font-size:.68rem; font-weight:700;
  letter-spacing:.12em; color:var(--accent); text-transform:uppercase; margin-bottom:.5rem;
}

/* ── Metric cards ── */
.mcard { background:var(--card); border:1px solid var(--border); border-radius:.7rem; padding:.9rem; text-align:center; }
.mval  { font-family:var(--hdisplay); font-size:2rem; font-weight:700; color:var(--accent); }
.mlbl  { font-size:.72rem; color:var(--muted); margin-top:.15rem; }

/* ── Inputs & buttons ── */
.stChatInput > div { background:var(--card) !important; border:1px solid var(--border) !important; border-radius:1rem !important; }
.stButton > button {
  background:var(--acsoft) !important; color:var(--accent) !important;
  border:1px solid var(--border) !important; border-radius:.55rem !important;
  font-family:var(--hbody) !important; font-weight:500 !important; transition:all .18s !important;
}
.stButton > button:hover { background:var(--acglow) !important; transform:translateY(-1px) !important; }
.stSelectbox > div > div, .stRadio > div, .stSlider > div { color:var(--text) !important; }
hr { border-color:var(--border) !important; }
::-webkit-scrollbar { width:5px; }
::-webkit-scrollbar-thumb { background:var(--border); border-radius:3px; }

/* ── Empty state ── */
.empty-state { text-align:center; padding:3rem 0; color:var(--muted); }
.empty-state .icon { font-size:3rem; margin-bottom:.8rem; }
.empty-state p { font-size:1rem; font-weight:300; }

/* ── Suggestion chips ── */
.chips { display:flex; gap:.5rem; flex-wrap:wrap; justify-content:center; margin:1.2rem 0; }
.chip {
  background:var(--acsoft); border:1px solid var(--border);
  padding:.35rem .85rem; border-radius:999px; font-size:.8rem; color:var(--text); cursor:pointer;
}
</style>
""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# SESSION STATE
# ══════════════════════════════════════════════════════════════════════════════
def init_session():
    defaults = {
        "messages":       [],
        "provider":       DEFAULT_PROVIDER,
        "mode":           "detailed",
        "rag_on":         True,
        "web_auto":       True,
        "temperature":    0.65,
        "collection":     None,
        "indexed_files":  [],
        "show_analytics": False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v
    init_analytics(st.session_state)
    if st.session_state.collection is None:
        try:
            st.session_state.collection = get_or_create_collection()
        except Exception as e:
            logger.warning(f"ChromaDB init failed: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════
def render_sidebar():
    with st.sidebar:
        # Logo block
        st.markdown("""
        <div style="text-align:center;padding:1.2rem 0 1.5rem">
          <div style="font-size:2.2rem">🩺</div>
          <div style="font-family:'Syne',sans-serif;font-size:1.05rem;font-weight:800;
               background:linear-gradient(135deg,#00d4aa,#7eb8f7);
               -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text">
               MediBot</div>
          <div style="font-size:.66rem;color:#7a8fa6;letter-spacing:.12em">AI HEALTH ASSISTANT</div>
        </div>""", unsafe_allow_html=True)

        # ── LLM Provider ──────────────────────────────────────────────────────
        st.markdown('<div class="slabel">🤖 LLM Provider</div>', unsafe_allow_html=True)
        avail = get_available_providers()
        opts  = [p for p, ok in avail.items() if ok] or ["groq"]
        labels = {"openai": "OpenAI GPT-4o-mini", "groq": "Groq Llama3-70B", "gemini": "Gemini 1.5 Flash"}
        sel_idx = opts.index(st.session_state.provider) if st.session_state.provider in opts else 0
        st.session_state.provider = st.selectbox(
            "prov", opts, index=sel_idx,
            format_func=lambda x: labels.get(x, x),
            label_visibility="collapsed",
        )

        # ── Response Mode ─────────────────────────────────────────────────────
        st.markdown('<div class="slabel" style="margin-top:1rem">💬 Response Mode</div>', unsafe_allow_html=True)
        st.session_state.mode = st.radio(
            "mode",
            ["concise", "detailed", "eli5"],
            index=["concise", "detailed", "eli5"].index(st.session_state.mode),
            format_func=lambda m: {"concise": "⚡ Concise", "detailed": "📋 Detailed", "eli5": "🧒 ELI5"}[m],
            label_visibility="collapsed",
        )

        # ── Temperature ───────────────────────────────────────────────────────
        st.markdown('<div class="slabel" style="margin-top:1rem">🌡️ Creativity</div>', unsafe_allow_html=True)
        st.session_state.temperature = st.slider(
            "temp", 0.0, 1.0, st.session_state.temperature, 0.05,
            label_visibility="collapsed",
        )

        st.divider()

        # ── Feature Toggles ───────────────────────────────────────────────────
        st.markdown('<div class="slabel">⚙️ Features</div>', unsafe_allow_html=True)
        st.session_state.rag_on   = st.toggle("📚 Knowledge Base (RAG)", value=st.session_state.rag_on)
        st.session_state.web_auto = st.toggle("🌐 Auto Web Search",      value=st.session_state.web_auto)

        st.divider()

        # ── Document Upload ───────────────────────────────────────────────────
        st.markdown('<div class="slabel">📄 Upload Documents</div>', unsafe_allow_html=True)
        uploads = st.file_uploader(
            "Upload PDFs, TXTs, DOCXs",
            type=["pdf", "txt", "docx", "md"],
            accept_multiple_files=True,
            label_visibility="collapsed",
        )
        if uploads and st.button("📥 Index Documents", use_container_width=True):
            prog = st.progress(0)
            for i, f in enumerate(uploads):
                if f.name not in st.session_state.indexed_files:
                    suffix = os.path.splitext(f.name)[1]
                    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                        tmp.write(f.getbuffer()); tmp_path = tmp.name
                    try:
                        n = index_document(tmp_path, st.session_state.collection)
                        st.session_state.indexed_files.append(f.name)
                        st.success(f"✅ {f.name} — {n} chunks")
                    except Exception as e:
                        st.error(f"❌ {f.name}: {e}")
                    finally:
                        os.unlink(tmp_path)
                prog.progress((i + 1) / len(uploads))

        if st.session_state.indexed_files:
            st.caption(f"📎 {len(st.session_state.indexed_files)} file(s) indexed")
            for fn in st.session_state.indexed_files:
                st.caption(f"   • {fn}")
            if st.button("🗑️ Clear Knowledge Base", use_container_width=True):
                if clear_collection():
                    st.session_state.indexed_files = []
                    st.session_state.collection = get_or_create_collection()
                    st.success("Knowledge base cleared.")

        st.divider()

        # ── Session Controls ──────────────────────────────────────────────────
        st.markdown('<div class="slabel">🗂️ Session</div>', unsafe_allow_html=True)
        c1, c2 = st.columns(2)
        with c1:
            if st.button("🧹 Clear", use_container_width=True):
                st.session_state.messages = []
                st.rerun()
        with c2:
            if st.session_state.messages:
                st.download_button(
                    "⬇️ Export",
                    data=format_chat_for_export(st.session_state.messages),
                    file_name=f"medibot_{datetime.now().strftime('%Y%m%d_%H%M')}.txt",
                    mime="text/plain",
                    use_container_width=True,
                )

        if st.button("📊 Analytics", use_container_width=True):
            st.session_state.show_analytics = not st.session_state.show_analytics

        # KB stats
        try:
            stats = get_collection_stats(st.session_state.collection)
            st.caption(f"🗄️ {stats['total_chunks']} chunks in knowledge base")
        except Exception:
            pass

        st.caption(f"v{APP_VERSION} · MediBot by NeoStats")


# ══════════════════════════════════════════════════════════════════════════════
# HEADER
# ══════════════════════════════════════════════════════════════════════════════
def render_header():
    avail  = get_available_providers()
    rag_ok = bool(st.session_state.indexed_files)

    rag_cls  = "pill-on" if (st.session_state.rag_on and rag_ok) else ("pill-warn" if st.session_state.rag_on else "pill-off")
    web_cls  = "pill-on" if st.session_state.web_auto else "pill-off"
    prov_cls = "pill-on" if avail.get(st.session_state.provider) else "pill-warn"
    mode_map = {"concise": "⚡ Concise", "detailed": "📋 Detailed", "eli5": "🧒 ELI5"}

    st.markdown(f"""
    <div class="mb-header">
      <h1>🩺 MediBot</h1>
      <p>{APP_TAGLINE}</p>
      <div class="mb-badge">v{APP_VERSION}</div>
      <div class="pills" style="margin-top:.9rem">
        <span class="pill {rag_cls}">📚 {'RAG Active' if rag_ok else 'RAG (No Docs)'}</span>
        <span class="pill {web_cls}">🌐 {'Web Search On' if st.session_state.web_auto else 'Web Off'}</span>
        <span class="pill {prov_cls}">🤖 {st.session_state.provider.upper()}</span>
        <span class="pill pill-on">💬 {mode_map[st.session_state.mode]}</span>
      </div>
    </div>
    """, unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# ANALYTICS PANEL
# ══════════════════════════════════════════════════════════════════════════════
def render_analytics():
    s = get_summary(st.session_state)
    if not s:
        return
    st.markdown("---")
    st.markdown("### 📊 Session Analytics")
    c1, c2, c3 = st.columns(3)
    for col, val, lbl in [
        (c1, s["total"], "Total Queries"),
        (c2, s["rag"],   "RAG Hits"),
        (c3, s["web"],   "Web Searches"),
    ]:
        with col:
            st.markdown(f'<div class="mcard"><div class="mval">{val}</div><div class="mlbl">{lbl}</div></div>',
                        unsafe_allow_html=True)
    if s["cats"]:
        st.markdown("**Query Categories:**")
        total = max(s["total"], 1)
        for cat, cnt in sorted(s["cats"].items(), key=lambda x: -x[1]):
            pct = int(cnt / total * 100)
            st.markdown(f"`{cat}` — {cnt} ({pct}%)")


# ══════════════════════════════════════════════════════════════════════════════
# MESSAGE RENDERER
# ══════════════════════════════════════════════════════════════════════════════
def render_messages():
    if not st.session_state.messages:
        st.markdown("""
        <div class="empty-state">
          <div class="icon">💊</div>
          <p>Ask me anything about health, symptoms, medications, or medical research.</p>
          <p style="font-size:.82rem;margin-top:.3rem;opacity:.6">
            I'll use your uploaded documents and live web search to give the best answer.
          </p>
        </div>
        <div class="chips">
          <span class="chip">💊 Ibuprofen side effects?</span>
          <span class="chip">🧬 Explain CRISPR therapy</span>
          <span class="chip">🫀 Heart attack vs panic attack</span>
          <span class="chip">🧠 Signs of high cortisol</span>
        </div>
        """, unsafe_allow_html=True)
        return

    for msg in st.session_state.messages:
        role     = msg["role"]
        content  = msg["content"]
        ts       = msg.get("ts", "")
        used_rag = msg.get("rag", False)
        used_web = msg.get("web", False)

        if role == "user":
            st.markdown(f"""
            <div class="msg user">
              <div class="avatar user">👤</div>
              <div>
                <div class="bubble user">{content}</div>
                <div class="meta" style="text-align:right">{ts}</div>
              </div>
            </div>""", unsafe_allow_html=True)
        else:
            tags = ""
            if used_rag: tags += '<span class="tag tag-rag">📚 RAG</span>'
            if used_web: tags += '<span class="tag tag-web">🌐 Web</span>'

            # Use st.container to allow markdown rendering inside the bubble area
            with st.container():
                st.markdown(f"""
                <div class="msg bot">
                  <div class="avatar bot">🩺</div>
                  <div style="max-width:76%">
                    <div class="bubble bot">
                """, unsafe_allow_html=True)
                st.markdown(content)
                st.markdown(f"""
                    </div>
                    <div>{tags}</div>
                    <div class="meta">{ts}</div>
                  </div>
                </div>""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# RESPONSE ORCHESTRATION
# ══════════════════════════════════════════════════════════════════════════════
def generate_response(query: str) -> tuple[str, bool, bool]:
    """
    Orchestrate RAG → Web Search → LLM streaming.

    Returns:
        (full_response_text, used_rag, used_web)
    """
    rag_ctx  = ""
    web_ctx  = ""
    used_rag = False
    used_web = False

    # 1. RAG retrieval
    if st.session_state.rag_on and st.session_state.collection:
        try:
            chunks = retrieve_relevant_chunks(query, collection=st.session_state.collection)
            if chunks:
                rag_ctx  = build_rag_context(chunks)
                used_rag = True
        except Exception as e:
            logger.error(f"RAG error: {e}")

    # 2. Web search (auto-triggered by keywords)
    if st.session_state.web_auto and should_search_web(query):
        try:
            results = web_search(query, max_results=4)
            if results:
                web_ctx  = format_search_results(results)
                used_web = True
        except Exception as e:
            logger.error(f"Web search error: {e}")

    # 3. Build messages
    messages = build_messages(
        user_query   = query,
        chat_history = st.session_state.messages,
        rag_context  = rag_ctx,
        web_context  = web_ctx,
    )

    # 4. Stream tokens
    full = ""
    placeholder = st.empty()
    try:
        for token in get_llm_response(
            messages      = messages,
            provider      = st.session_state.provider,
            response_mode = st.session_state.mode,
            temperature   = st.session_state.temperature,
        ):
            full += token
            placeholder.markdown(full + "▌")
        placeholder.markdown(full)
    except Exception as e:
        full = f"⚠️ Error generating response: {e}"
        placeholder.markdown(full)
        logger.error(f"LLM error: {e}")

    return full, used_rag, used_web


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
def main():
    init_session()
    render_sidebar()
    render_header()

    if st.session_state.show_analytics:
        render_analytics()

    render_messages()

    # ── Input ──────────────────────────────────────────────────────────────────
    if prompt := st.chat_input("Ask MediBot a health question…"):
        now = datetime.now().strftime("%H:%M")

        # Emergency check — show banner before generating response
        if detect_emergency(prompt):
            st.markdown(f'<div class="emg">{EMERGENCY_BANNER}</div>', unsafe_allow_html=True)

        # Store user message
        st.session_state.messages.append({"role": "user", "content": prompt, "ts": now})

        # Generate & stream response
        with st.spinner(""):
            response, used_rag, used_web = generate_response(prompt)

        # Store bot message
        st.session_state.messages.append({
            "role": "assistant",
            "content": response,
            "ts":  datetime.now().strftime("%H:%M"),
            "rag": used_rag,
            "web": used_web,
        })

        # Analytics
        record_query(
            st.session_state,
            category = classify_query(prompt),
            provider = st.session_state.provider,
            mode     = st.session_state.mode,
            used_rag = used_rag,
            used_web = used_web,
        )

        st.rerun()


if __name__ == "__main__":
    main()
