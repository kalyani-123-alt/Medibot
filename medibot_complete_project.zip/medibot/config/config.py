"""
config/config.py
━━━━━━━━━━━━━━━━
Central configuration hub for MediBot AI Health Assistant.
All secrets are loaded from environment variables or .env file.
NEVER hard-code API keys here.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ─── LLM Provider Keys ─────────────────────────────────────────────────────────
OPENAI_API_KEY  = os.getenv("OPENAI_API_KEY", "")
GROQ_API_KEY    = os.getenv("GROQ_API_KEY", "")
GEMINI_API_KEY  = os.getenv("GEMINI_API_KEY", "")

# ─── Web Search Keys ───────────────────────────────────────────────────────────
TAVILY_API_KEY  = os.getenv("TAVILY_API_KEY", "")   # Primary search API

# ─── Embedding / Vector Store ──────────────────────────────────────────────────
CHROMA_PERSIST_DIR = os.getenv("CHROMA_PERSIST_DIR", "./chroma_db")
EMBEDDING_MODEL    = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
CHUNK_SIZE         = int(os.getenv("CHUNK_SIZE", "500"))
CHUNK_OVERLAP      = int(os.getenv("CHUNK_OVERLAP", "60"))
TOP_K_RESULTS      = int(os.getenv("TOP_K_RESULTS", "5"))

# ─── LLM Model Defaults ────────────────────────────────────────────────────────
DEFAULT_PROVIDER = os.getenv("DEFAULT_LLM_PROVIDER", "groq")

LLM_MODELS = {
    "openai": "gpt-4o-mini",
    "groq":   "llama3-70b-8192",
    "gemini": "gemini-1.5-flash",
}

# ─── Response Mode Instructions ────────────────────────────────────────────────
RESPONSE_MODE_PROMPTS = {
    "concise": (
        "Keep your reply to 2–4 sentences maximum. Be direct and factual. "
        "Skip examples unless absolutely necessary."
    ),
    "detailed": (
        "Provide a comprehensive, well-structured answer using markdown formatting. "
        "Include headers, bullet points, examples, and reasoning. Be thorough."
    ),
    "eli5": (
        "Explain this as if the user is 12 years old. Use very simple words, "
        "everyday analogies, and zero jargon. Make it friendly and fun."
    ),
}

# ─── App Metadata ──────────────────────────────────────────────────────────────
APP_NAME     = "MediBot"
APP_TAGLINE  = "AI-Powered Health Intelligence Assistant"
APP_VERSION  = "2.0.0"
MAX_HISTORY  = 20
