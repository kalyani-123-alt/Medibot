"""
models/embeddings.py
━━━━━━━━━━━━━━━━━━━━
Embedding model interface for the RAG pipeline.

Uses sentence-transformers locally — no API key required.
Provides a ChromaDB-compatible EmbeddingFunction wrapper.

Invoked from: app.py (via utils/rag_utils.py)
"""

import logging
from typing import Optional

from config.config import EMBEDDING_MODEL

logger = logging.getLogger(__name__)

# Module-level model cache — avoids reloading on every call
_model_cache: dict = {}


def _load_model(model_name: str):
    """Load and cache a SentenceTransformer model."""
    if model_name not in _model_cache:
        try:
            from sentence_transformers import SentenceTransformer
            logger.info(f"[Embeddings] Loading model: {model_name}")
            _model_cache[model_name] = SentenceTransformer(model_name)
            logger.info(f"[Embeddings] Model '{model_name}' loaded successfully.")
        except Exception as e:
            logger.error(f"[Embeddings] Failed to load model '{model_name}': {e}")
            raise RuntimeError(f"Could not load embedding model: {e}") from e
    return _model_cache[model_name]


def embed_texts(texts: list[str], model_name: Optional[str] = None) -> list[list[float]]:
    """
    Embed a list of strings into dense vectors.

    Args:
        texts:      Strings to embed.
        model_name: Override the default model (EMBEDDING_MODEL from config).

    Returns:
        List of float vectors, one per input string.
    """
    try:
        model = _load_model(model_name or EMBEDDING_MODEL)
        vectors = model.encode(texts, show_progress_bar=False, normalize_embeddings=True)
        return vectors.tolist()
    except Exception as e:
        logger.error(f"[Embeddings] embed_texts error: {e}")
        raise


def embed_query(query: str, model_name: Optional[str] = None) -> list[float]:
    """
    Embed a single query string optimised for retrieval.

    Args:
        query:      Query string.
        model_name: Override the default model.

    Returns:
        A single float vector.
    """
    try:
        return embed_texts([query], model_name)[0]
    except Exception as e:
        logger.error(f"[Embeddings] embed_query error: {e}")
        raise


class EmbeddingFunction:
    """
    ChromaDB-compatible embedding function.

    Plug this into a ChromaDB collection so the collection
    automatically uses our local HuggingFace model.

    Usage:
        ef = EmbeddingFunction()
        collection = client.get_or_create_collection("kb", embedding_function=ef)
    """

    def __init__(self, model_name: Optional[str] = None):
        self.model_name = model_name or EMBEDDING_MODEL
        # Pre-load at instantiation time so first query is fast
        self._model = _load_model(self.model_name)

    def __call__(self, input: list[str]) -> list[list[float]]:
        try:
            vectors = self._model.encode(
                input,
                show_progress_bar=False,
                normalize_embeddings=True,
            )
            return vectors.tolist()
        except Exception as e:
            logger.error(f"[EmbeddingFunction] Error: {e}")
            raise
