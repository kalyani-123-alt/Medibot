"""
models/llm.py
━━━━━━━━━━━━━
Unified LLM interface supporting OpenAI, Groq, and Google Gemini.
All providers support token streaming for a responsive UI.

Response-mode style instructions are injected into the system prompt
so the same function handles Concise / Detailed / ELI5 automatically.
"""

import logging
from typing import Generator, Optional

from config.config import (
    OPENAI_API_KEY, GROQ_API_KEY, GEMINI_API_KEY,
    LLM_MODELS, RESPONSE_MODE_PROMPTS,
)

logger = logging.getLogger(__name__)


# ─── OpenAI ────────────────────────────────────────────────────────────────────
def _stream_openai(messages: list[dict], model: str, temperature: float) -> Generator[str, None, None]:
    try:
        from openai import OpenAI
        client = OpenAI(api_key=OPENAI_API_KEY)
        stream = client.chat.completions.create(
            model=model, messages=messages, temperature=temperature, stream=True,
        )
        for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                yield delta
    except Exception as e:
        logger.error(f"[LLM/OpenAI] {e}")
        yield f"⚠️ OpenAI error: {e}"


# ─── Groq ──────────────────────────────────────────────────────────────────────
def _stream_groq(messages: list[dict], model: str, temperature: float) -> Generator[str, None, None]:
    try:
        from groq import Groq
        client = Groq(api_key=GROQ_API_KEY)
        stream = client.chat.completions.create(
            model=model, messages=messages, temperature=temperature, stream=True,
        )
        for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                yield delta
    except Exception as e:
        logger.error(f"[LLM/Groq] {e}")
        yield f"⚠️ Groq error: {e}"


# ─── Google Gemini ─────────────────────────────────────────────────────────────
def _stream_gemini(messages: list[dict], model: str, temperature: float) -> Generator[str, None, None]:
    try:
        import google.generativeai as genai
        genai.configure(api_key=GEMINI_API_KEY)
        gmodel = genai.GenerativeModel(model)

        history, system_prefix = [], ""
        for m in messages:
            role, content = m["role"], m["content"]
            if role == "system":
                system_prefix = content
            elif role == "user":
                history.append({"role": "user", "parts": [content]})
            elif role == "assistant":
                history.append({"role": "model", "parts": [content]})

        if system_prefix and history and history[0]["role"] == "user":
            history[0]["parts"][0] = f"{system_prefix}\n\n{history[0]['parts'][0]}"

        chat = gmodel.start_chat(history=history[:-1] if len(history) > 1 else [])
        last_user_text = history[-1]["parts"][0] if history else ""
        for chunk in chat.send_message(last_user_text, stream=True):
            if chunk.text:
                yield chunk.text
    except Exception as e:
        logger.error(f"[LLM/Gemini] {e}")
        yield f"⚠️ Gemini error: {e}"


# ─── Public API ────────────────────────────────────────────────────────────────
_DISPATCH = {"openai": _stream_openai, "groq": _stream_groq, "gemini": _stream_gemini}


def get_llm_response(
    messages: list[dict],
    provider: str = "groq",
    response_mode: str = "detailed",
    temperature: float = 0.7,
    custom_model: Optional[str] = None,
) -> Generator[str, None, None]:
    """
    Stream tokens from the chosen LLM provider.

    Args:
        messages:      Full conversation as [{role, content}] dicts.
        provider:      'openai' | 'groq' | 'gemini'
        response_mode: 'concise' | 'detailed' | 'eli5'
        temperature:   0.0 – 1.0
        custom_model:  Override the default model string for the provider.

    Yields:
        String tokens as they arrive from the API.
    """
    model = custom_model or LLM_MODELS.get(provider, LLM_MODELS["groq"])

    # Inject response-mode instruction into the system message
    mode_instr = RESPONSE_MODE_PROMPTS.get(response_mode, "")
    enriched = list(messages)
    if enriched and enriched[0]["role"] == "system":
        enriched[0] = {**enriched[0], "content": enriched[0]["content"] + f"\n\n[Style]: {mode_instr}"}
    else:
        enriched.insert(0, {"role": "system", "content": mode_instr})

    fn = _DISPATCH.get(provider)
    if not fn:
        yield f"⚠️ Unknown provider: '{provider}'"
        return

    yield from fn(enriched, model, temperature)


def get_available_providers() -> dict[str, bool]:
    """Return which providers have API keys configured."""
    return {
        "openai": bool(OPENAI_API_KEY),
        "groq":   bool(GROQ_API_KEY),
        "gemini": bool(GEMINI_API_KEY),
    }
