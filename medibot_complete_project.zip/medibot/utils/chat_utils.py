"""
utils/chat_utils.py
━━━━━━━━━━━━━━━━━━━
Conversation management helpers:
  - System prompt construction with date injection
  - Message list building (history + context + query)
  - Emergency keyword detection with Indian helpline numbers
  - Query classification for analytics
  - Chat history export formatter
"""

import re
import logging
from datetime import datetime
from typing import Optional

from config.config import MAX_HISTORY

logger = logging.getLogger(__name__)

# ─── System Prompt ─────────────────────────────────────────────────────────────
_SYSTEM_PROMPT_TEMPLATE = """You are MediBot, an advanced AI Health Intelligence Assistant.

## What You Do
- Explain medical concepts, symptoms, lab results, and medications clearly
- Summarise clinical research and medical literature
- Provide evidence-based wellness and prevention guidance
- Retrieve and cite information from uploaded medical documents (RAG)
- Search for the latest medical news and research when needed

## Non-Negotiable Rules
1. ALWAYS remind users to consult a licensed healthcare professional for personal decisions.
2. NEVER diagnose. You can explain possibilities — not conclusions.
3. Flag emergency symptoms immediately with emergency contact numbers.
4. Cite retrieved documents and web sources when you use them.
5. Be honest about uncertainty. Say "I'm not sure" rather than guess.

## Tone
Warm · precise · evidence-based · jargon-free when possible.

Today's date: {date}
"""

def build_system_prompt() -> str:
    return _SYSTEM_PROMPT_TEMPLATE.format(date=datetime.now().strftime("%B %d, %Y"))


# ─── Message Builder ───────────────────────────────────────────────────────────
def build_messages(
    user_query:    str,
    chat_history:  list[dict],
    rag_context:   str = "",
    web_context:   str = "",
    system_prompt: Optional[str] = None,
) -> list[dict]:
    """
    Assemble the full messages list for the LLM call.

    Structure:
      [system]  → system prompt (+ date)
      [user]    → context block (RAG + web), if any
      [asst]    → acknowledgement
      [...hist] → trimmed conversation history
      [user]    → current query
    """
    messages = [{"role": "system", "content": system_prompt or build_system_prompt()}]

    # Inject context if present
    context_parts = [p for p in [rag_context, web_context] if p]
    if context_parts:
        ctx = "\n\n---\n\n".join(context_parts)
        messages.append({
            "role": "user",
            "content": (
                "Use the following context to answer accurately. "
                "If it is insufficient, rely on your training knowledge.\n\n" + ctx
            ),
        })
        messages.append({
            "role": "assistant",
            "content": "Understood. I will use this context and cite it where relevant.",
        })

    # Trimmed history
    messages.extend(chat_history[-MAX_HISTORY:])
    messages.append({"role": "user", "content": user_query})
    return messages


# ─── Emergency Detection ───────────────────────────────────────────────────────
_EMERGENCY_TERMS = [
    "chest pain", "heart attack", "stroke", "can't breathe", "difficulty breathing",
    "unconscious", "overdose", "suicidal", "suicide", "severe bleeding", "seizure",
    "anaphylaxis", "allergic reaction", "not breathing", "choking",
]

EMERGENCY_BANNER = """
⚠️ **POSSIBLE MEDICAL EMERGENCY DETECTED**

Your message contains keywords that may indicate a medical emergency.

**If this is an emergency, please act NOW:**
- 🚨 **India Emergency**: Call **112**
- 🏥 Go to the nearest Emergency Room immediately
- 📞 **iCall (Mental Health Crisis)**: 9152987821
- 📞 **Vandrevala Foundation**: 1860-2662-345 (24/7)

---
I will answer your question below, but **please prioritise your safety first.**
"""

def detect_emergency(query: str) -> bool:
    q = query.lower()
    return any(term in q for term in _EMERGENCY_TERMS)


# ─── Query Classification ──────────────────────────────────────────────────────
_CATEGORIES = {
    "symptom":      ["symptom", "pain", "ache", "fever", "headache", "nausea", "dizzy", "fatigue"],
    "medication":   ["drug", "medicine", "medication", "dose", "dosage", "side effect", "pill", "tablet"],
    "research":     ["study", "research", "trial", "paper", "evidence", "journal", "published", "review"],
    "nutrition":    ["diet", "nutrition", "food", "vitamin", "supplement", "calorie", "eating", "weight"],
    "mental_health":["anxiety", "depression", "stress", "mental", "therapy", "mood", "sleep", "insomnia"],
    "prevention":   ["prevent", "vaccine", "vaccination", "screening", "check", "risk", "lifestyle"],
}

def classify_query(query: str) -> str:
    q = query.lower()
    for category, keywords in _CATEGORIES.items():
        if any(kw in q for kw in keywords):
            return category
    return "general"


# ─── Export ────────────────────────────────────────────────────────────────────
def format_chat_for_export(history: list[dict]) -> str:
    now   = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [f"MediBot Chat Export — {now}", "=" * 60, ""]
    for msg in history:
        speaker = "You" if msg["role"] == "user" else "MediBot"
        lines.append(f"[{speaker}]")
        lines.append(msg["content"])
        lines.append("")
    return "\n".join(lines)
