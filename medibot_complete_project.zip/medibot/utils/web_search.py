"""
utils/web_search.py
━━━━━━━━━━━━━━━━━━━
Live web search integration.

Strategy:
  1. Tavily API  (premium — fast, high-quality, medical-aware)
  2. DuckDuckGo  (free fallback — no API key required)

API keys managed in config/config.py as environment variables.
"""

import logging
from typing import Optional

from config.config import TAVILY_API_KEY

logger = logging.getLogger(__name__)


# ─── Tavily (Primary) ──────────────────────────────────────────────────────────
def _search_tavily(query: str, max_results: int) -> list[dict]:
    """Search via Tavily API. Returns [] if key is not set or call fails."""
    if not TAVILY_API_KEY:
        logger.debug("[WebSearch] Tavily key not set — skipping.")
        return []
    try:
        from tavily import TavilyClient
        client   = TavilyClient(api_key=TAVILY_API_KEY)
        response = client.search(query=query, search_depth="advanced", max_results=max_results)
        results  = []
        for r in response.get("results", []):
            results.append({
                "title":   r.get("title", ""),
                "url":     r.get("url",   ""),
                "content": r.get("content", "")[:700],
                "source":  "Tavily",
            })
        logger.info(f"[WebSearch] Tavily → {len(results)} results")
        return results
    except Exception as e:
        logger.error(f"[WebSearch] Tavily error: {e}")
        return []


# ─── DuckDuckGo (Fallback) ─────────────────────────────────────────────────────
def _search_duckduckgo(query: str, max_results: int) -> list[dict]:
    """Search via DuckDuckGo — no API key needed."""
    try:
        from duckduckgo_search import DDGS
        results = []
        with DDGS() as ddgs:
            for r in ddgs.text(query, max_results=max_results):
                results.append({
                    "title":   r.get("title", ""),
                    "url":     r.get("href",  ""),
                    "content": r.get("body",  "")[:700],
                    "source":  "DuckDuckGo",
                })
        logger.info(f"[WebSearch] DuckDuckGo → {len(results)} results")
        return results
    except Exception as e:
        logger.error(f"[WebSearch] DuckDuckGo error: {e}")
        return []


# ─── Public Interface ──────────────────────────────────────────────────────────
def web_search(
    query:          str,
    max_results:    int = 5,
    force_provider: Optional[str] = None,
) -> list[dict]:
    """
    Perform a live web search, Tavily → DuckDuckGo fallback.

    Args:
        query:          Natural-language query string.
        max_results:    Maximum results to return.
        force_provider: 'tavily' | 'duckduckgo' to override auto-selection.

    Returns:
        List of {title, url, content, source} dicts.
    """
    if force_provider == "tavily":
        return _search_tavily(query, max_results)
    if force_provider == "duckduckgo":
        return _search_duckduckgo(query, max_results)

    results = _search_tavily(query, max_results)
    if not results:
        logger.info("[WebSearch] Falling back to DuckDuckGo.")
        results = _search_duckduckgo(query, max_results)
    return results


def format_search_results(results: list[dict]) -> str:
    """Format search results into an LLM-readable context string."""
    if not results:
        return ""
    lines = ["🌐 **Live Web Search Results:**\n"]
    for i, r in enumerate(results, 1):
        lines.append(
            f"[{i}] **{r['title']}** ({r['source']})\n"
            f"URL: {r['url']}\n"
            f"{r['content']}\n"
        )
    return "\n".join(lines)


# Trigger keywords that suggest a web search would help
_SEARCH_TRIGGERS = {
    "latest", "recent", "current", "today", "news", "2024", "2025", "2026",
    "fda", "who", "cdc", "nih", "trial", "approved", "outbreak", "pandemic",
    "study", "research", "published", "statistics", "guideline", "vaccine",
}

def should_search_web(query: str) -> bool:
    """Heuristic: return True if the query likely benefits from a web search."""
    q = query.lower()
    return any(kw in q for kw in _SEARCH_TRIGGERS)
