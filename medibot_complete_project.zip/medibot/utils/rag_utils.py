"""
utils/rag_utils.py
━━━━━━━━━━━━━━━━━━
RAG (Retrieval-Augmented Generation) pipeline.

Flow:
  1. load_document()  — read PDF / TXT / DOCX / MD from disk
  2. chunk_text()     — split into overlapping word-windows
  3. index_document() — embed + upsert into ChromaDB
  4. retrieve_relevant_chunks() — cosine-similarity search
  5. build_rag_context() — format chunks into an LLM context string
"""

import os
import logging
import hashlib
from pathlib import Path
from typing import Optional

import chromadb
from chromadb.config import Settings

from config.config import (
    CHROMA_PERSIST_DIR, CHUNK_SIZE, CHUNK_OVERLAP, TOP_K_RESULTS,
)
from models.embeddings import EmbeddingFunction

logger = logging.getLogger(__name__)
COLLECTION_NAME = "medibot_kb"


# ─── ChromaDB helpers ──────────────────────────────────────────────────────────
def get_chroma_client():
    """Return a persistent ChromaDB client."""
    try:
        return chromadb.PersistentClient(
            path=CHROMA_PERSIST_DIR,
            settings=Settings(anonymized_telemetry=False),
        )
    except Exception as e:
        logger.error(f"[RAG] ChromaDB client error: {e}")
        raise


def get_or_create_collection(client=None):
    """Get or create the main knowledge-base collection."""
    try:
        if client is None:
            client = get_chroma_client()
        ef = EmbeddingFunction()
        return client.get_or_create_collection(
            name=COLLECTION_NAME,
            embedding_function=ef,
            metadata={"hnsw:space": "cosine"},
        )
    except Exception as e:
        logger.error(f"[RAG] Collection error: {e}")
        raise


# ─── Document loading ──────────────────────────────────────────────────────────
def load_document(file_path: str) -> str:
    """
    Load a document from disk and return its plain-text content.
    Supported: .txt, .md, .pdf, .docx
    """
    path = Path(file_path)
    ext  = path.suffix.lower()
    try:
        if ext in (".txt", ".md"):
            return path.read_text(encoding="utf-8", errors="ignore")

        elif ext == ".pdf":
            import fitz  # PyMuPDF
            doc  = fitz.open(str(path))
            text = "\n".join(page.get_text() for page in doc)
            doc.close()
            return text

        elif ext == ".docx":
            from docx import Document
            doc = Document(str(path))
            return "\n".join(p.text for p in doc.paragraphs if p.text.strip())

        else:
            logger.warning(f"[RAG] Unsupported extension: {ext}")
            return ""

    except Exception as e:
        logger.error(f"[RAG] load_document({file_path}): {e}")
        return ""


# ─── Chunking ──────────────────────────────────────────────────────────────────
def chunk_text(
    text: str,
    chunk_size: int = CHUNK_SIZE,
    overlap:    int = CHUNK_OVERLAP,
    source:     str = "",
) -> list[dict]:
    """
    Split text into overlapping word-windows.

    Returns:
        List of dicts: {text, source, chunk_index}
    """
    if not text.strip():
        return []

    words   = text.split()
    chunks  = []
    idx     = 0
    ci      = 0

    while idx < len(words):
        window = words[idx: idx + chunk_size]
        chunks.append({"text": " ".join(window), "source": source, "chunk_index": ci})
        idx += chunk_size - overlap
        ci  += 1

    logger.info(f"[RAG] '{source}' → {len(chunks)} chunks")
    return chunks


def _chunk_id(source: str, chunk_index: int) -> str:
    return hashlib.md5(f"{source}::{chunk_index}".encode()).hexdigest()


# ─── Indexing ──────────────────────────────────────────────────────────────────
def index_document(file_path: str, collection=None) -> int:
    """
    Load, chunk, and upsert a document into ChromaDB.

    Returns:
        Number of chunks indexed (0 on failure).
    """
    try:
        if collection is None:
            collection = get_or_create_collection()

        text = load_document(file_path)
        if not text:
            logger.warning(f"[RAG] Empty document: {file_path}")
            return 0

        source = os.path.basename(file_path)
        chunks = chunk_text(text, source=source)
        if not chunks:
            return 0

        ids   = [_chunk_id(c["source"], c["chunk_index"]) for c in chunks]
        docs  = [c["text"] for c in chunks]
        metas = [{"source": c["source"], "chunk_index": c["chunk_index"]} for c in chunks]

        # Batch upsert (ChromaDB limit: ~5000/call)
        batch = 200
        for i in range(0, len(ids), batch):
            collection.upsert(
                ids=ids[i: i+batch],
                documents=docs[i: i+batch],
                metadatas=metas[i: i+batch],
            )

        logger.info(f"[RAG] Indexed {len(chunks)} chunks from '{source}'")
        return len(chunks)

    except Exception as e:
        logger.error(f"[RAG] index_document error: {e}")
        return 0


# ─── Retrieval ─────────────────────────────────────────────────────────────────
def retrieve_relevant_chunks(
    query:      str,
    top_k:      int = TOP_K_RESULTS,
    collection  = None,
) -> list[dict]:
    """
    Retrieve the top-K most relevant chunks for a query.

    Returns:
        List of dicts: {text, source, chunk_index, relevance_score}
    """
    try:
        if collection is None:
            collection = get_or_create_collection()
        if collection.count() == 0:
            return []

        results = collection.query(
            query_texts=[query],
            n_results=min(top_k, collection.count()),
            include=["documents", "metadatas", "distances"],
        )

        chunks = []
        for doc, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ):
            chunks.append({
                "text":            doc,
                "source":          meta.get("source", "unknown"),
                "chunk_index":     meta.get("chunk_index", 0),
                "relevance_score": round(1 - dist, 4),
            })

        return chunks

    except Exception as e:
        logger.error(f"[RAG] retrieve_relevant_chunks error: {e}")
        return []


def build_rag_context(chunks: list[dict], max_chars: int = 3500) -> str:
    """Format retrieved chunks into a context string for the LLM."""
    if not chunks:
        return ""

    lines = ["📚 **Knowledge Base Context:**\n"]
    used  = 0
    for i, c in enumerate(chunks, 1):
        entry = (
            f"[{i}] Source: {c['source']} | Relevance: {c['relevance_score']:.0%}\n"
            f"{c['text'][:500]}\n"
        )
        if used + len(entry) > max_chars:
            break
        lines.append(entry)
        used += len(entry)

    return "\n".join(lines)


def get_collection_stats(collection=None) -> dict:
    """Return basic stats about the ChromaDB collection."""
    try:
        if collection is None:
            collection = get_or_create_collection()
        return {"total_chunks": collection.count(), "collection": COLLECTION_NAME}
    except Exception as e:
        logger.error(f"[RAG] stats error: {e}")
        return {"total_chunks": 0, "collection": COLLECTION_NAME}


def clear_collection() -> bool:
    """Delete all documents from the ChromaDB collection."""
    try:
        client = get_chroma_client()
        client.delete_collection(COLLECTION_NAME)
        logger.info("[RAG] Collection cleared.")
        return True
    except Exception as e:
        logger.error(f"[RAG] clear_collection error: {e}")
        return False
