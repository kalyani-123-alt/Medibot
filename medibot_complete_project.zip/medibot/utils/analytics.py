"""
utils/analytics.py
━━━━━━━━━━━━━━━━━━
Session-level analytics — stored in Streamlit session_state only.
No PII is tracked. All data resets when the session ends.
"""

import logging
from datetime import datetime
from collections import Counter

logger = logging.getLogger(__name__)


def init_analytics(ss) -> None:
    """Initialise analytics dict in Streamlit session state."""
    if "analytics" not in ss:
        ss.analytics = {
            "total_queries":   0,
            "rag_hits":        0,
            "web_hits":        0,
            "categories":      Counter(),
            "providers":       Counter(),
            "modes":           Counter(),
            "session_start":   datetime.now().strftime("%H:%M"),
        }


def record_query(ss, *, category: str, provider: str, mode: str,
                 used_rag: bool = False, used_web: bool = False) -> None:
    """Record one query event."""
    try:
        a = ss.analytics
        a["total_queries"] += 1
        if used_rag: a["rag_hits"] += 1
        if used_web: a["web_hits"] += 1
        a["categories"][category] += 1
        a["providers"][provider]  += 1
        a["modes"][mode]          += 1
    except Exception as e:
        logger.error(f"[Analytics] record_query: {e}")


def get_summary(ss) -> dict:
    """Return a clean summary dict for the dashboard."""
    try:
        a = ss.analytics
        return {
            "total":    a["total_queries"],
            "rag":      a["rag_hits"],
            "web":      a["web_hits"],
            "cats":     dict(a["categories"]),
            "provs":    dict(a["providers"]),
            "modes":    dict(a["modes"]),
            "started":  a["session_start"],
        }
    except Exception as e:
        logger.error(f"[Analytics] get_summary: {e}")
        return {}
